import React, { useState } from 'react';
import { COLORS } from '../constants/colors';
import { Car, Factory, HardHat, GitBranch } from '../components/Icons';
import mockSourceAttribution from '../mockData/sourceAttribution';

const SourceAttribution = () => {
  const [data, setData] = useState(mockSourceAttribution);
  const probabilities = (data as any).probabilities;

  const chartData = probabilities
    ? [
        { name: 'Traffic', value: probabilities.Traffic * 100, color: COLORS.traffic, icon: Car },
        { name: 'Industry', value: probabilities.Industry * 100, color: COLORS.industry, icon: Factory },
        { name: 'Construction', value: probabilities.Construction * 100, color: COLORS.construction, icon: HardHat },
      ]
    : [
        { name: 'Traffic', value: (data as any).traffic ?? 0, color: COLORS.traffic, icon: Car },
        { name: 'Industry', value: (data as any).industry ?? 0, color: COLORS.industry, icon: Factory },
        { name: 'Construction', value: (data as any).construction ?? 0, color: COLORS.construction, icon: HardHat },
        { name: 'Mixed Source', value: (data as any).mixed_source ?? 0, color: COLORS.mixed_source, icon: GitBranch },
      ];

  return (
    <div>
      {/* Component JSX here */}
    </div>
  );
};

export default SourceAttribution;
